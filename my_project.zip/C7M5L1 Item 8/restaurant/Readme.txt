
Note:-
1. url for crating new users: '/registration'
2. please pass token of user while accessing /book/ and /reservations/
3. get token by accessing djoser endpoint. [i have implemented djoser in the project]


if you have any doubt or  question, Please mention in comment.
Thank you.



submitted by 'Kabir Kumar'.